# -*- coding: utf-8 -*-
from __future__ import unicode_literals
def dfs(graph, start):
    visited = set()

    def dfs_helper(node):
        visited.add(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                dfs_helper(neighbor)

    dfs_helper(start)
    return visited
