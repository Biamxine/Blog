# -*- coding: utf-8 -*-
from __future__ import unicode_literals
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        last_node = self.head
        while last_node.next is not None:
            last_node = last_node.next
        last_node.next = new_node

    def print_list(self):
        current_node = self.head
        while current_node is not None:
            print(current_node.data)
            current_node = current_node.next

    def delete(self, data):
        current_node = self.head
        if current_node is not None and current_node.data == data:
            self.head = current_node.next
            current_node = None
            return

        previous_node = None
        while current_node is not None and current_node.data != data:
            previous_node = current_node
            current_node = current_node.next

        if current_node is None:
            return

        previous_node.next = current_node.next
        current_node = None


linked_list = LinkedList()
linked_list.append(1)
linked_list.append(2)
linked_list.append(3)

print("所有节点:")
linked_list.print_list()

linked_list.delete(2)

print("删除2后所有节点:")
linked_list.print_list()
