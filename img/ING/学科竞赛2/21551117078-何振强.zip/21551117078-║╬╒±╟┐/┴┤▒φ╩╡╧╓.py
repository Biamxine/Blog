class Node:
    def __init__(self, value):
        self.value = value
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def add_node(self, value):
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node

    def remove_node(self, value):
        if self.head is None:
            return
        if self.head.value == value:
            self.head = self.head.next
            return
        current = self.head
        prev = None
        while current and current.value != value:
            prev = current
            current = current.next
        if current:
            prev.next = current.next

    def print_list(self):
        current = self.head
        while current:
            print(current.value)
            current = current.next

# 创建LinkedList实例
linked_list = LinkedList()

# 在链表末尾添加节点值为1
linked_list.add_node(1)

# 在链表末尾添加节点值为2
linked_list.add_node(2)

# 在链表末尾添加节点值为3
linked_list.add_node(3)

# 打印链表中所有节点的值
linked_list.print_list()

# 删除节点值为2的节点
linked_list.remove_node(2)

# 打印链表中所有节点的值
linked_list.print_list()
