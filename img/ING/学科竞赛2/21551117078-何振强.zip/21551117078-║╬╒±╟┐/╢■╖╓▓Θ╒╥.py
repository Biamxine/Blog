def binary_search(nums, target):
    left = 0
    right = len(nums) - 1

    while left <= right:
        mid = (left + right) // 2
        if nums[mid] == target:
            return mid
        elif nums[mid] < target:
            left = mid + 1
        else:
            right = mid - 1

    return -1
#示例用法
nums = [1, 2, 3, 4, 5, 6, 7, 8, 9]
target = 6
result = binary_search(nums, target)
print("目标值在列表中的索引位置：", result)

