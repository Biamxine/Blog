def selection_sort(nums):
    n = len(nums)
    for i in range(n):
        min_idx = i
        for j in range(i+1, n):
            if nums[j] < nums[min_idx]:
                min_idx = j
        nums[i], nums[min_idx] = nums[min_idx], nums[i]
    return nums
#示例用法
nums = [6, 2, 8, 4, 1, 9, 3, 7, 5]
sorted_nums = selection_sort(nums)
print("排序后的列表：", sorted_nums)
